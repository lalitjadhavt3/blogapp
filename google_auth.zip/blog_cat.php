<!DOCTYPE html>
<html lang="en">
    
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags-->
        <!-- Title-->
        <title>News Ten - Blog &amp; Magazine Mobile HTML Template</title>
        <!-- Favicon-->
        <link rel="icon" href="test/img/core-img/favicon.ico" />
        <!-- Stylesheet-->
        <link rel="stylesheet" href="test/style.css" />
        <link rel="stylesheet" type="text/css" href="slick\slick.min.css" />
        <link rel="stylesheet" type="text/css" href="slick\slick-theme.min.css" />
    </head>
    <body>
        <!-- Preloader-->
        <div class="preloader" id="preloader">
            <div class="spinner-grow text-secondary" role="status">
                <div class="sr-only">Loading...</div>
            </div>
        </div>
        <!-- Header Area-->
         
        <!-- Center Modal-->
        <div class="page-content-wrapper">
            <div class="catagory-posts-wrapper">
                <div class="container">
                    <div class="d-flex align-items-center justify-content-between">
                        <?php 
                            extract($_GET);
                            require 'db.php';
                            $select = "select * from blog_cat where blog_cat.cat_id = '$cat'";
                            
                            //mysqli_real_escape_string($con);
                            if ($result = $con->query($select)) {
                             
                                while ($data = $result->fetch_assoc()) {
                                    echo '<h5 class="mb-3 pl-2 newsten-title">'.$data["cat_name"].'</h5>';
                                }
                            }
                        ?>
                        
                    </div>
                </div>
                <div class="container">
                    <!-- Single News Post-->
                     <?php 
                         extract($_GET);
                         require 'db.php';
                         $select = "select * from blog_images inner join user_blogs on user_blogs.id = blog_images.blog_id inner join blog_cat on user_blogs.blog_cat = blog_cat.cat_id where blog_cat.cat_id = '$cat'";
                         mysqli_query($con,"SET CHARACTER SET 'utf8'");
                         mysqli_query($con,"SET SESSION collation_connection ='utf8_unicode_ci'");
                         //mysqli_real_escape_string($con);
                         $res = $con->query($select);
                         $numrow = mysqli_num_rows($res);
                         if($numrow > 0)
                         {
                                 if ($result = $con->query($select)) {
                                  
                                     while ($data = $result->fetch_assoc()) {

                                        $realpath = dirname($data["imgname"]);
                                    $path = str_replace($realpath, "", trim($data["imgname"]));
                                    $path=  "blog_img".$path; 
                                   
                                   echo '<div class="single-news-post d-flex align-items-center bg-gray">
                                <div class="post-thumbnail">
                                    
                                    <img src="'.$path.'" alt="" />
                                </div>
                                <div class="post-content">
                                    <a class="post-title" href="single.html">'.$data["blog_title"].'</a>
                                    <div class="post-meta d-flex align-items-center"><a href="#">'.$data["blog_date"].'</a></div>
                                </div>
                            </div>';
                            extract($data);
                                }
                            }
                         }
                        
                    else{
                        echo "<h3>There no blog posts under this category</h3><br><a class='btn btn-info' href='dashboard.php'>Go Back</a>";
                    }

                     ?>
                    
                    
                </div>
                
            </div>
        </div>
        
        <!-- Footer Nav-->
        <div class="footer-nav-area" id="footerNav">
          <div class="newsten-footer-nav h-100">
            <ul class="h-100 d-flex r" style="width: 105%;justify-content: space-evenly;">
              <li class="active">
                <a href="dashboard.php"><i class="lni lni-home"></i> Home</a>
              </li>
              <li >
                <a href="profile.php"><i class="lni lni-user"></i> Profile</a>
              </li>
              
            </ul>
          </div>
        </div>
        <!-- All JavaScript Files-->
        <script src="test/js/jquery.min.js"></script>

        <script src="test/js/popper.min.js"></script>
        <script src="test/js/bootstrap.min.js"></script>
        <script src="test/js/waypoints.min.js"></script>
        <script src="test/js/jquery.easing.min.js"></script>
        <script src="test/js/owl.carousel.min.js"></script>
        <script src="test/js/jquery.animatedheadline.min.js"></script>
        <script src="test/js/jquery.counterup.min.js"></script>
        <script src="test/js/wow.min.js"></script>
        <script src="test/js/default/date-clock.js"></script>
        <script src="test/js/default/dark-mode-switch.js"></script>
        <script src="test/js/default/scrollindicator.js"></script>
        <script src="test/js/default/active.js"></script>
        <script type="text/javascript" src="slick\slick.min.js"></script>

    </body>
   
</html>
